ZYHRA'S PORTFOLIO — VERCEL DEPLOYMENT GUIDE

Included file:
- index.html — the customized purple-and-black, mobile-friendly portfolio.

BEFORE YOU PUBLISH
1. Open index.html in a text editor if you want to edit it.
2. Replace your.email@example.com with an email address you want to share.
3. Update the sample skills and project descriptions to match your real experience.
4. The profile photo is currently a placeholder, as requested.

PUBLISH FROM AN ANDROID PHONE
1. Download and extract this ZIP using your phone's Files app.
2. Open https://github.com in Chrome and sign in or create an account.
3. Create a new repository (for example, zyhra-portfolio). Public is easiest for a simple portfolio.
4. Open the repository, choose Add file > Upload files, select index.html from the extracted folder, and commit the upload.
5. Open https://vercel.com in Chrome and sign in. If needed, use the browser menu and choose Desktop site.
6. On the Vercel dashboard choose Add New > Project.
7. Import the GitHub repository you created. If prompted, authorize Vercel to access that repository.
8. For this plain HTML website, leave the framework preset as Other (or no framework), leave build/output settings blank/default, and click Deploy.
9. When deployment finishes, open the provided .vercel.app URL to see your site.

UPDATES LATER
Edit index.html, upload/commit the changed file to the same GitHub repository, and Vercel will normally redeploy automatically.

PRIVACY TIP
Only publish contact details and links you are comfortable making public.
